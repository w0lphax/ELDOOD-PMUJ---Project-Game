import pygame
pygame.init()

class Platform:
    def __init__(self,x,y,dx,dy,type_platform):
        self.x=x
        self.y=y
        self.dx=dx
        self.dy=dy
        self.type_platform = type_platform
        self.stock = x
        self.tour = 0
        
    def dimension(self):
        return (self.x,self.y,50,10)
    
    def mouvement(self):
        self.y=self.y+self.dy
        
    def acc_x(self):
        return self.x
    
    def acc_y(self):
        return self.y
    
    def acc_type_platform(self):
        return self.type_platform

    def mouvementSpe(self):
        if self.x<=self.stock+100 and self.stock+self.dx*self.tour<self.stock+100:
            self.x+=self.dx
            self.tour+=1
        else:
            self.x-=self.dx
            if self.stock>=self.x:
                self.tour=0  