import pygame
from Module_personnage import Personnage
from Module_platform import Platform
from random import randint
pygame.init()
pygame.mixer.init() #module audio de pygame


nb_frames = 0

pers = Personnage(395,690,10,0)

son_saut = pygame.mixer.Sound("mario-jump-sound-effect.mp3")
pygame.mixer.music.load("Techno - Tetris (Remix).mp3")
pygame.mixer.music.set_volume(1)
pygame.mixer.music.play(-1)

image_perso = pygame.image.load("KEKW.png")
image_perso = pygame.ransform.scale(image_perso, (40, 40))
fenetre = pygame.display.set_mode((500, 800))
Horloge_FPS = pygame()
Game_over = False 


platforms = [
    Platform(390, 730, 0, 10, 1), 
    Platform(150, 700, 0, 10, 1),
    Platform(280, 620, 0, 10, 1),
    Platform(180, 540, 0, 10, 1),
    Platform(320, 460, 0, 10, 2), #Coordonnées plateformes de départ
    Platform(220, 380, 0, 10, 1), 
    Platform(100, 300, 0, 10, 1),
    Platform(250, 220, 0, 10, 2),
    Platform(370, 140, 0, 10, 1),
    Platform(200, 60, 0, 10, 1)
]

platform_compteur_score = Platform(290, 850, 0, 10, 1) #on utilise son y pour compter le score

#AFFICHAGE
def afficher():
    fenetre.fill((255,255,255)) #arrière-plan en blanc
    font = pygame.font.SysFont("c   omicsansms", 30)#charge la police et règle sa taille à 30 (pour Game Over et score
    petite_font = pygame.font.SysFont("comicsansms", 17)#charge la police et règle sa taille 20 (pour le texte du mode hardcore)
    if hard_mode:
                fenetre.fill((0,0,0))
                texte_mode_hardcore = petite_font.render("HARDCORE MODE", True, (255, 0, 0))
                fenetre.blit(texte_mode_hardcore, (10, 65)) #affiche le texte du mode hardcore dans le jeu

    fenetre.blit(image_perso, (pers.x, pers.y)) #affiche l'image du perso sur ses coordonnées (là où il est)
    
    for platform in platforms:
        if not hard_mode:  
            pygame.draw.rect(fenetre,(0,0,0),platform.dimension()) #dessine les plateformes
        elif hard_mode and nb_frames%60==0: #la condition est vrai une fois par seconde environ, car le jeu tourne à 60 fps
            pygame.draw.rect(fenetre,(255, 255, 255),platform.dimension()) #dessine les plateformes en blanc

        
    if pers.acc_y()>800: #si il est "mort" (il a disparu de l'écran))
        police = pygame.font.SysFont("comicsansms", 48, bold=True)
        message_Normal_mode = police.render("Game Over", True, (255, 0,0))
        
        if hard_mode :
            police_hard_mode = pygame.font.SysFont("comicsansms", 28, bold=True)
            message_hard_mode = police_hard_mode.render("You’ve gotten way too confident.", True, (255, 0,0))
            
        if hard_mode:
            fenetre.blit(message_hard_mode, (25, 380))
        else:
            fenetre.blit(message_Normal_mode, (125, 380))
    
#AFFICHAGE - SCORE
    texte_score = font.render("Score : " + str(score), True, (randint(0,255), randint(0,255), randint(0,255)))
    fenetre.blit(texte_score, (10, 10))
    
    pygame.display.flip() #met à jour l'affichage du jeu
    
#RESTART
def restart():
    pers = Personnage(395,690,10,0)
    platforms = [
        Platform(390,730,0,10,1),
        Platform(150,700,0,10,1),
        Platform(280,620,0,10,1),
        Platform(180,540,0,10,1),
        Platform(320,460,0,10,1),
        Platform(220,380,0,10,1),
        Platform(100,300,0,10,1),
        Platform(250,220,0,10,1),
        Platform(370,140,0,10,1),
        Platform(200,60,0,10,1)]
    score = 0

    Game_over = False
    platform_compteur_score = Platform(290,850,0,10,1)

    return pers, platforms, score, platform_compteur_score, Game_over


######################################################################################################################################################################


#BOUCLE PRINCIPALE
score = 0
jeu = True
hard_mode = False 

while jeu:
    Horloge_FPS.tick(60) #régler/limiter les fps à 60
    print(Horloge_FPS.get_fps())
    nb_frames += 1
    
    for evenement in pygame.event.get():
        if evenement.type == pygame.QUIT: #si on clique sur la croix rouge pour fermer le jeu
            jeu = False
            
        #Restart et Mode Hardcore
        if evenement.type == pygame.KEYDOWN:
            if evenement.key == pygame.K_RCTRL and not hard_mode:
                hard_mode = True
            elif evenement.key == pygame.K_RCTRL and hard_mode:
                hard_mode = False
            if evenement.key == pygame.K_r:
                pers, platforms, score, platform_compteur_score, Game_over = restart()
                 
#BINDINGS
    touches = pygame.key.get_pressed() #permet de savoir quelles touches sont appuyées
    if touches[pygame.K_LEFT]:
        pers.x -= 5
        if pers.x < 0:
            pers.x = 460
            
    if touches[pygame.K_RIGHT]:
        pers.x += 5
        if pers.x > 460:
            pers.x = 0
      
#GRAVITE
    pers.dy += 0.37 #y diminue sur l'axe verticale
    pers.y += pers.dy
    
    compteur_plateformes = 0

    if pers.acc_y() > 800:
        Game_over = True
    
#SCORE
    if pers.y < 300:
        platform_compteur_score.mouvement()
        while score < platform_compteur_score.acc_y():
            score += 1

#COLLISIONS
    pers_rect = pygame.Rect(pers.dimension()) #on crée le rectangle (hitbox) du personnage(avec les dimensions de pers donc 40x40)

    for platform in platforms:
        platform_rect = pygame.Rect(platform.dimension()) #on crée le rectangle (hitbox) pour chaque plateforme (avec les dimensions de platform donc 50x10)

        if pers_rect.colliderect(platform_rect) and pers.dy > 0: #si les deux rectangles (hitbox) se touchent et que le perso est en train de tomber
            pers.dy = -10 #on le fait sauter
            son_saut.play()
            
        if pers.y < 300: #mouvement des platforms
            platform.mouvement()
                    
            if platform.acc_y()>800:
                platforms.pop(compteur_plateformes) #supprime à chaque fois le premier élément de la liste platforms(la plateforme qui est sortie de l'écran)
                pourcentage = randint(0, 100)
                if pourcentage%9 == 0 : #1 chance sur 9 de créer une plateforme mouvante
                    platforms.append(Platform(randint(0,450), 0, 3.5, 10,2)) #création plateforme mouvante
                else:
                    platforms.append(Platform(randint(0,450), 0, 0, 10,1)) #création plateforme normale
        compteur_plateformes += 1
        if platform.acc_type_platform() == 2:
            platform.mouvementSpe()

    afficher()