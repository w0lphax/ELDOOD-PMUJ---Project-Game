WARNING : Pour des raisons que nous ignorons, lorsque vous décompressez le dossier du jeu, la ligne 19 et 21 sont modifiés : Il faut changer :
- "image_perso = pygame.ransform.scale(image_perso, (40, 40))" par "image_perso = pygame.transform.scale(image_perso, (40, 40))"  (la manipulation à faire est d'ajouter le "t" à "transform")
- "Horloge_FPS = pygame()"  par "Horloge_FPS = pygame.time.Clock()"  (ajouter ".time.Clock" à "pygame") 

-------------------------------------------------------------------------------------------------------------------------------------------------

ELDOOD PMUJ est notre jeu dérivé du célèbre jeu Doodle Jump dans lequel nous incarnons un personnages aux atraits cubiques dans lequel l'objectif est d'obtenir le meilleur score possible ! Mais attention à ne pas trop vous surestimez : le mode Hardcore pourrait vous laisser bouche bé. 


Pietro s'est occupé du score, de l'intégration du son, du mode hardcore, du restart, de l'affichage. Hugo s'est occupé de la création et de l'intégration des plateformes mouvantes, ainsi que la création des différentes méthodes nécessaires au jeu dans Module_platform et Module_personnage. Nous avons réfléchi ensemble à la création des variables nécessaires et à leur utilité : par exemple "platform_compteur_score"; "Game_Over"; etc...
Nous avons travaillé en commun sur la gravité du personnage, la création des plateformes, des bindings (déplacement du personnage, activation du mode Hardcore), et de l'interaction du personnage avec les plateformes (collision, rebond du personnage).

Nous avons eu besoin de la recherche Google pour trouver des fonctions pour répondre à nos souhaits : 
-le son : .mixer.Sound;.music.load;.music.set_volume;.music.play;.mixer.init;
-l'affichage : image.load;.transform_scale;.display.set_mode;.font.SysFont;.render;.draw.rect;.blit;.fill;.time.Clock;.tick
-les collisions entre les hitbox : .colliderect;.Rect
-les touches : .key.get_pressed;.KEYDOWN
Ainsi que .init()

L'IA nous a permis de savoir qu'il faut créer une boucle de jeu principal et son importance dans le fonctionnement du jeu : elle nous a informé des fonctions .event.get; .type et .QUIT. Elle nous a été utile pour la recherche d'une police d'écriture en lien avec l'atmosphère du jeu, et nous a permis de trouver des coordonnées corrects pour les 10 premières plateformes de départs qui sont positionnées par défaut.