import pygame
pygame.init()


class Personnage:
    def __init__(self,x,y,dx,dy):
        self.x=x
        self.y=y
        self.dy=dy
        self.dx=dx
        
    def couleur(self,a,b,c): #Pour le code d'Hugo
        return (a,b,c)
    
    def dimension(self):
        return (self.x,self.y,40,40)
    
    def acc_x(self):
        return self.x
    
    def acc_y(self):
        return self.y
    